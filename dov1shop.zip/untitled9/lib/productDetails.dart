
import 'package:flutter/material.dart';



final List<String> ImageContent = [
  'https://static.re-store.ru/upload/resize_cache/iblock/81c/100500_800_140cd750bba9870f18aada2478b24840a/81c9dec4a635089a852179fec11c8c4e.jpg',
  'https://static.re-store.ru/upload/resize_cache/iblock/de9/100500_800_140cd750bba9870f18aada2478b24840a/de95c2cd619ee8c849b14717d9074110.jpg',
  'https://static.re-store.ru/upload/resize_cache/iblock/dbb/100500_800_140cd750bba9870f18aada2478b24840a/rgg3oswbof2f1i4ox1x7ociautmnyzu2.jpg',
  'https://static.re-store.ru/upload/resize_cache/iblock/571/100500_800_140cd750bba9870f18aada2478b24840a/y3bk2sn2r9f6vgj5uxothtp3qgbeenlu.png',
  'https://static.re-store.ru/upload/resize_cache/iblock/d76/100500_800_140cd750bba9870f18aada2478b24840a/d7687c4047344a6ebd92a158b08ea272.jpg',
  'https://static.re-store.ru/upload/resize_cache/iblock/3b6/100500_800_140cd750bba9870f18aada2478b24840a/elb3uz6iey7j7x08qeq10av0nyhj1bjz.jpg',
  'https://static.re-store.ru/upload/resize_cache/iblock/490/100500_800_140cd750bba9870f18aada2478b24840a/490589c25c309dd76b78188b6b7ef013.jpg',
  'https://static.re-store.ru/upload/resize_cache/iblock/b4d/100500_800_140cd750bba9870f18aada2478b24840a/bqyj12l8gewqcp2cxmwpy27jjap8a9fc.jpg',
  'https://static.re-store.ru/upload/resize_cache/iblock/acf/100500_800_140cd750bba9870f18aada2478b24840a/ns1xi5ftv53e15zuvj2qomf3ft1v83y8.jpg',
  'https://static.re-store.ru/upload/iblock/b2e/38jzmxo8n4lkqw4207rayd4qktu6t37r.png',
  'https://static.re-store.ru/upload/resize_cache/iblock/1e6/100500_800_140cd750bba9870f18aada2478b24840a/gn4n0dufw0vn142m97j6xy4s7abus19j.jpeg',
];

final List<String> TextContent = [
  'IPhone 52 Mini',
  'AirPods Max',
  'Apple Watch Ultra 2 GPS + Cellular',
  'MacBook Air ',
  'IPad Pro 2022',
  'Apple iMac',
  'Apple iPad 2021',
  'Airpods Pro 2',
  'Apple Watch Series 9',
  'Apple Mac Studio (M2 Ultra, 2023)',
  'Apple iPhone 15 Pro Max',
];

final List<double> PriceContent = [1499.52, 199.52, 15.52, 299.52, 52188.52, 29.52, 100000.52, 249.52, 199.52, 29.52, 19.52];

final List<String> productDescription = [
  'Процессор: 6-ядерный Apple A15 Bionic (4-ядерная графика) Камера: 12 Мп, f/1,6 (широкоугольная) + 12 Мп, f/2,4 (сверхширокоугольная); 12 Мп, f/2,2 (фронтальная) Память: 4 ГБ оперативной, 128/256/512 ГБ постоянной Батарея: 2500 мАч, быстрая зарядка 20 Вт, беспроводная зарядка MagSafe и Qi.',
  'Наушники AirPods Max отличаются запоминающимся стильным видом, способным выделить вас среди толпы. Сочетание цельнометаллических чашек и мягкого силикона с эффектом памяти даёт не только элегантную внешность, но и комфорт для ваших ушей и головы, к форме которых наушники приспосабливаются самым оптимальным способом.',
  'Apple Watch Ultra (1-го поколения) — дорогое семейство сверхзащищённых (водонепроницаемость до 100 м глубины погружения) смарт-часов Apple Watch в титановый корпусе для экстремалов новой серии «Ultra», построенные на чипе Apple S8 и вышедшие 7 сентября 2022 года. Первое поколение серии «Ultra».',
  'Macbook Air оснащается 13,3-дюймовым дисплеем с разрешением 1440 x 900 пикселей, процессором Intel Core i5, графическим процессором Intel HD Graphics 3000 и батареей, обеспечивающей 7 часов непрерывного веб-серфинга по Wi-Fi. В ноутбуке отсутствуют оптический привод и жесткий диск.',
  'Он включает в себя 8-ядерный центральный процессор, графический процессор с 10 ядрами и систему машинного обучения Neural Engine из 16 ядер. Продвинутая версия оснащается встроенной памятью от 128 ГБ до 2 ТБ. Владельцы базовой версии могут хранить файлы в памяти объемом от 64 ГБ до 256 ГБ в зависимости от конфигурации.',
  'iMac 2023 года впечатляет невероятно ярким дисплеем Retina 4.5К. Кроме того, он оснащен фронтальной камерой FaceTime HD 1080p, шестью динамиками с поддержкой Spatial Audio и Dolby Atmos, а также три микрофоном, позволяющим записывать звук в студийном качестве',
  'Планшет Apple iPad (2021) Wi-Fi 64 ГБ сочетает стильный дизайн и мощные характеристики. В его основе содержатся процессор A13 Bionic и 3 ГБ оперативной памяти, которые обеспечивают производительность и быстродействие системы при выполнении различных задач.',
  'AirPods Pro 2 были переработаны для еще более насыщенного воспроизведения звука. Активное шумоподавление следующего уровня и адаптивная прозрачность снижают уровень внешних шумов. Пространственный звук выводит погружение на удивительно личный уровень.',
  'Apple Watch 9 имеют OLED-дисплей с высоким разрешением, максимальную яркость в 2000 нит и минимальную в 1 нит. Ремешки для умных часов изготовлены из экологичного текстильного материала Fine Woven. Улучшенная производительность, большая автономность, новый чип S9 и полезные функции мониторинга здоровья.',
  'Mac Studio — новый настольный компьютер Mac. Сочетает в себе невероятную производительность, широкие возможности подключения и в невероятно компактном корпусе, обеспечивая лёгкий доступ ко всему, что вам нужно, и превращая любое пространство в студию.',
  'Дисплей: 6,1 и 6,7 дюйма, LTPO Super Retina XDR OLED, 2556×1179 и 2796×1290, 1−120 Гц, не менее 2000 нит, HDR10, Dolby Vision, Always-On Display стекло Ceramic Shield, толщина рамок 1,55 мм. Чипсет: A17 Bionic. Оперативная память: 8 ГБ.',


];


class ProductDetailsPage extends StatelessWidget {
  final String ImageContent;
  final String TextContent;
  final String productDescription;

  ProductDetailsPage(
      {required this.ImageContent, required this.TextContent, required this.productDescription});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(TextContent),
        backgroundColor: Color(0xffB54426b),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 500,
              width: double.infinity,
              child: Image.network(
                ImageContent,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 20),
            Text(
              TextContent,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              productDescription,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(onPressed: () {}, child: Text('Liked')
                ),
                ElevatedButton(onPressed: () {}, child: Text('Cart')
                ),
                ElevatedButton(onPressed: () {}, child: Text('Buy in one click')
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}