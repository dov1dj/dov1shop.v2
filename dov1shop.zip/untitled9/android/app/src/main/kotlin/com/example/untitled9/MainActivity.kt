package com.example.untitled9

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
